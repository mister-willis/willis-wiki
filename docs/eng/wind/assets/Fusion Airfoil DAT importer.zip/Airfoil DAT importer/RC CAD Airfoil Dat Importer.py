import adsk.core
import adsk.fusion
import traceback
import os

# Global list to keep all event handlers in scope
handlers = []

def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        
        # Get the CommandDefinitions collection
        cmdDefs = ui.commandDefinitions
        
        # Check if the command already exists
        cmdDef = cmdDefs.itemById('AirfoilImporterCmd')
        if cmdDef:
            cmdDef.deleteMe()
        
        # Create a new command definition
        cmdDef = cmdDefs.addButtonDefinition(
            'AirfoilImporterCmd',
            'Import Airfoil',
            'Import airfoil from DAT file and create sketch',
            './resources'  # Icon folder
        )
        
        # Connect to the command created event
        onCommandCreated = CommandCreatedHandler()
        cmdDef.commandCreated.add(onCommandCreated)
        handlers.append(onCommandCreated)
        
        # Get the CREATE panel in the SOLID workspace
        solidWorkspace = ui.workspaces.itemById('FusionSolidEnvironment')
        createPanel = solidWorkspace.toolbarPanels.itemById('SolidCreatePanel')
        
        # Add the command to the CREATE panel
        buttonControl = createPanel.controls.addCommand(cmdDef, '', False)
        
    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

def stop(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        
        # Remove the button from the CREATE panel
        solidWorkspace = ui.workspaces.itemById('FusionSolidEnvironment')
        createPanel = solidWorkspace.toolbarPanels.itemById('SolidCreatePanel')
        buttonControl = createPanel.controls.itemById('AirfoilImporterCmd')
        if buttonControl:
            buttonControl.deleteMe()
        
        # Delete the command definition
        cmdDefs = ui.commandDefinitions
        cmdDef = cmdDefs.itemById('AirfoilImporterCmd')
        if cmdDef:
            cmdDef.deleteMe()
        
    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            cmd = args.command
            
            # Create the command inputs
            inputs = cmd.commandInputs
            
            # Add file selection input
            inputs.addStringValueInput('filePathInput', 'DAT File', '')
            inputs.addBoolValueInput('browseButton', 'Browse...', False)
            
            # Add chord length input
            inputs.addValueInput('chordLength', 'Chord Length', 'mm', adsk.core.ValueInput.createByReal(10.0))
            
            # Add plane selection input
            planeSelection = inputs.addSelectionInput('planeSelection', 'Sketch Plane', 'Select a plane or planar face')
            planeSelection.addSelectionFilter('PlanarFaces')
            planeSelection.addSelectionFilter('ConstructionPlanes')
            planeSelection.setSelectionLimits(1, 1)
            
            # Connect to the execute event
            onExecute = CommandExecuteHandler()
            cmd.execute.add(onExecute)
            handlers.append(onExecute)
            
            # Connect to the input changed event
            onInputChanged = CommandInputChangedHandler()
            cmd.inputChanged.add(onInputChanged)
            handlers.append(onInputChanged)
            
            # Connect to the validate inputs event
            onValidateInputs = CommandValidateInputsHandler()
            cmd.validateInputs.add(onValidateInputs)
            handlers.append(onValidateInputs)
            
        except:
            app = adsk.core.Application.get()
            ui = app.userInterface
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

class CommandInputChangedHandler(adsk.core.InputChangedEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.inputs
            changedInput = args.input
            
            # Handle browse button click
            if changedInput.id == 'browseButton':
                app = adsk.core.Application.get()
                ui = app.userInterface
                
                fileDialog = ui.createFileDialog()
                fileDialog.isMultiSelectEnabled = False
                fileDialog.title = "Select Airfoil DAT File"
                fileDialog.filter = "DAT Files (*.dat);;All Files (*.*)"
                
                dialogResult = fileDialog.showOpen()
                if dialogResult == adsk.core.DialogResults.DialogOK:
                    filename = fileDialog.filename
                    filePathInput = inputs.itemById('filePathInput')
                    filePathInput.value = filename
                    
        except:
            app = adsk.core.Application.get()
            ui = app.userInterface
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

class CommandValidateInputsHandler(adsk.core.ValidateInputsEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        try:
            inputs = args.inputs
            
            # Check if file is selected
            filePathInput = inputs.itemById('filePathInput')
            if not filePathInput.value or not os.path.exists(filePathInput.value):
                args.areInputsValid = False
                return
            
            # Check if plane is selected
            planeSelection = inputs.itemById('planeSelection')
            if planeSelection.selectionCount < 1:
                args.areInputsValid = False
                return
            
            args.areInputsValid = True
            
        except:
            args.areInputsValid = False

class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def __init__(self):
        super().__init__()
    def notify(self, args):
        ui = None
        try:
            app = adsk.core.Application.get()
            ui = app.userInterface
            
            inputs = args.command.commandInputs
            
            # Get the file path
            filePathInput = inputs.itemById('filePathInput')
            filename = filePathInput.value
            
            # Get the chord length
            chordLengthInput = inputs.itemById('chordLength')
            chord_length_cm = chordLengthInput.value
            
            # Get the selected plane
            planeSelection = inputs.itemById('planeSelection')
            selectedPlane = planeSelection.selection(0).entity
            
            # Read and parse the DAT file
            upper_surface, lower_surface = parse_airfoil_file(filename)
            
            if not upper_surface or not lower_surface:
                ui.messageBox('Failed to parse airfoil file. Please check the file format.')
                return
            
            # Create the sketch
            design = adsk.fusion.Design.cast(app.activeProduct)
            rootComp = design.rootComponent
            
            # Create a new sketch on the selected plane
            sketches = rootComp.sketches
            sketch = sketches.add(selectedPlane)
            
            # Create points for upper surface (flip Y to correct orientation)
            upper_points = adsk.core.ObjectCollection.create()
            for x, y in upper_surface:
                # Chord along X, thickness along Y (negated to flip upside down)
                point = adsk.core.Point3D.create(x * chord_length_cm, -y * chord_length_cm, 0)
                upper_points.add(point)
            
            # Create points for lower surface (flip Y to correct orientation)
            lower_points = adsk.core.ObjectCollection.create()
            for x, y in lower_surface:
                # Chord along X, thickness along Y (negated to flip upside down)
                point = adsk.core.Point3D.create(x * chord_length_cm, -y * chord_length_cm, 0)
                lower_points.add(point)
            
            # Draw splines through the points
            if upper_points.count > 0:
                upper_spline = sketch.sketchCurves.sketchFittedSplines.add(upper_points)
            
            if lower_points.count > 0:
                lower_spline = sketch.sketchCurves.sketchFittedSplines.add(lower_points)
            
        except:
            if ui:
                ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

def parse_airfoil_file(filename):
    """Parse the Lednicer format airfoil DAT file"""
    try:
        with open(filename, 'r') as f:
            lines = f.readlines()
        
        # Skip the title line
        current_line = 1
        
        # Read the count line (optional, we'll just look for blank line separator)
        current_line += 1
        
        upper_surface = []
        lower_surface = []
        
        # Read upper surface coordinates
        for i in range(current_line, len(lines)):
            line = lines[i].strip()
            if not line:  # Empty line separates upper and lower surfaces
                current_line = i + 1
                break
            
            parts = line.split()
            if len(parts) >= 2:
                try:
                    x = float(parts[0])
                    y = float(parts[1])
                    upper_surface.append((x, y))
                except ValueError:
                    continue
        
        # Read lower surface coordinates
        for i in range(current_line, len(lines)):
            line = lines[i].strip()
            if not line:
                continue
            
            parts = line.split()
            if len(parts) >= 2:
                try:
                    x = float(parts[0])
                    y = float(parts[1])
                    lower_surface.append((x, y))
                except ValueError:
                    continue
        
        return upper_surface, lower_surface
        
    except Exception as e:
        return None, None