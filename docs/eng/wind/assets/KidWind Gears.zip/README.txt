KidWind Gears by vernier on Thingiverse: https://www.thingiverse.com/thing:3612652

Summary:
These are the 8-, 16-, 32-, and 64-tooth gears included with the KidWind Advanced Wind Experiment Kit. 